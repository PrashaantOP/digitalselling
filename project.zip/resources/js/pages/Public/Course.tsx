import { Head, Link } from '@inertiajs/react';
import { ArrowRight, Award, Check, Clock, Lock, Play, Video } from 'lucide-react';

type Product = {
    id: number;
    title: string;
    slug: string;
    description: string | null;
    cover_type: 'image' | 'video' | null;
    cover_video_url: string | null;
    pricing_type: 'fixed' | 'customer_decides' | 'free';
    price: string | number;
    has_discount: boolean;
    discounted_price: string | number | null;
    button_text: string | null;
    theme: string | null;
    accent_color: string | null;
    cover_images: string[];
    checkout_questions: { id: number; label: string; field_type: 'text' | 'phone' | 'email' | 'number' | 'dropdown'; options: string[] | null; is_required: boolean; is_enabled: boolean }[];
    course: CourseData;
};

type CourseData = {
    access_type: 'lifetime' | 'days';
    access_days: number | null;
    certificate_enabled: boolean;
    total_lessons: number;
    modules: { id: number; title: string; lessons: { id: number; title: string; type: string; is_free_preview: boolean }[] }[];
    instructions: string[];
    benefits: string[];
    highlights: string[];
    faqs: { question: string; answer: string }[];
    testimonials: { name: string; message: string; avatar_path: string | null }[];
    gallery: string[];
    live_classes: { title: string; description: string | null; scheduled_at: string; duration_minutes: number }[];
};

type Props = { product: Product; creator: { name: string; username: string; avatar: string | null }; checkoutUrl: string };

const money = (value: string | number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(value) || 0);
const asset = (path: string | null) => (path ? `/assets/${path}` : '');

export default function Course({ product, creator, checkoutUrl }: Props) {
    const course = product.course;
    const accent = /^#[0-9A-Fa-f]{6}$/.test(product.accent_color ?? '') ? product.accent_color! : '#4F46E5';
    const price = product.pricing_type === 'free' ? 'Free' : product.pricing_type === 'customer_decides' ? 'Pay what you want' : money(product.has_discount && product.discounted_price ? product.discounted_price : product.price);
    const cover = product.cover_images?.[0];

    return (
        <>
            <Head title={product.title} />
            <main className="min-h-screen bg-[#FAF9F5] text-[#14141B]">
                <div className="h-1" style={{ backgroundColor: accent }} />
                <header className="border-b border-[#E4E2DA] bg-white">
                    <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-4">
                        <Link href="/" className="truncate text-sm font-bold">{creator.name || creator.username}</Link>
                        <span className="text-xs text-[#6B6B78]">Online course</span>
                    </div>
                </header>

                <section className="mx-auto grid max-w-6xl gap-8 px-5 py-10 lg:grid-cols-[minmax(0,1fr)_340px] lg:py-16">
                    <div>
                        {cover && <img src={asset(cover)} alt="" className="mb-8 aspect-video w-full rounded-2xl object-cover shadow-sm" />}
                        <h1 className="text-4xl leading-tight font-extrabold tracking-tight md:text-5xl">{product.title}</h1>
                        {product.description && <div className="mt-6 whitespace-pre-line text-base leading-8 text-[#4B4B57]">{product.description}</div>}

                        {course.highlights.length > 0 && <Section title="Highlights"><div className="flex flex-wrap gap-2">{course.highlights.map((item) => <span key={item} className="rounded-full px-3 py-1.5 text-sm font-semibold" style={{ backgroundColor: `${accent}18`, color: accent }}>{item}</span>)}</div></Section>}
                        {course.benefits.length > 0 && <Section title="What you get"><ul className="grid gap-3 sm:grid-cols-2">{course.benefits.map((item) => <li key={item} className="flex gap-2 text-sm"><Check className="mt-0.5 size-4 shrink-0" style={{ color: accent }} />{item}</li>)}</ul></Section>}
                        {course.instructions.length > 0 && <Section title="Course instructions"><ul className="list-disc space-y-2 pl-5 text-sm text-[#4B4B57]">{course.instructions.map((item) => <li key={item}>{item}</li>)}</ul></Section>}
                        <Section title="Course content">
                            <div className="space-y-3">
                                {course.modules.length === 0 ? (
                                    <p className="text-sm text-[#6B6B78]">Course content will appear here soon.</p>
                                ) : (
                                    course.modules.map((module) => (
                                        <div key={module.id} className="overflow-hidden rounded-xl border border-[#E4E2DA] bg-white">
                                            <h2 className="border-b border-[#E4E2DA] px-4 py-3 text-sm font-bold">{module.title}</h2>
                                            {module.lessons.map((lesson) => (
                                                <div key={lesson.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                                                    <Play className="size-4" style={{ color: accent }} />
                                                    <span className="min-w-0 flex-1 truncate">{lesson.title}</span>
                                                    {lesson.is_free_preview ? <span className="text-xs font-semibold" style={{ color: accent }}>Free preview</span> : <Lock className="size-3.5 text-[#8A8A96]" />}
                                                </div>
                                            ))}
                                        </div>
                                    ))
                                )}
                            </div>
                        </Section>
                        {course.live_classes.length > 0 && <Section title="Live classes"><div className="space-y-2">{course.live_classes.map((item) => <div key={item.title} className="flex items-center gap-3 rounded-xl border border-[#E4E2DA] bg-white p-4 text-sm"><Video className="size-4" style={{ color: accent }} /><span className="font-semibold">{item.title}</span></div>)}</div></Section>}
                    </div>

                    <aside className="h-fit rounded-2xl border border-[#E4E2DA] bg-white p-6 shadow-sm lg:sticky lg:top-6">
                        <div className="flex items-center gap-2 text-sm text-[#6B6B78]"><Clock className="size-4" /> {course.access_type === 'days' ? `${course.access_days} days access` : 'Lifetime access'}</div>
                        {course.certificate_enabled && <div className="mt-3 flex items-center gap-2 text-sm text-[#6B6B78]"><Award className="size-4" /> Certificate included</div>}
                        <p className="mt-6 text-3xl font-extrabold">{price}</p>
                        {product.checkout_questions.length > 0 && (
                            <div className="mt-6 flex flex-col gap-3 border-t border-[#E4E2DA] pt-5">
                                {product.checkout_questions.map((question) => (
                                    <label key={question.id} className="flex flex-col gap-1.5 text-xs font-semibold text-[#4B4B57]">
                                        {question.label}
                                        {question.field_type === 'dropdown' ? (
                                            <select required={question.is_required} className="h-11 rounded-lg border border-[#DAD8D0] bg-white px-3 text-sm font-normal text-[#14141B] outline-none focus:border-[#4F46E5]">
                                                <option value="">Select {question.label.toLowerCase()}</option>
                                                {(question.options ?? []).map((option) => <option key={option} value={option}>{option}</option>)}
                                            </select>
                                        ) : (
                                            <input type={question.field_type === 'email' ? 'email' : question.field_type === 'number' ? 'number' : question.field_type === 'phone' ? 'tel' : 'text'} required={question.is_required} className="h-11 rounded-lg border border-[#DAD8D0] bg-white px-3 text-sm font-normal text-[#14141B] outline-none focus:border-[#4F46E5]" />
                                        )}
                                    </label>
                                ))}
                            </div>
                        )}
                        <a href={checkoutUrl} className="mt-6 flex h-12 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold text-white" style={{ backgroundColor: accent }}>{product.button_text || 'Enroll now'} <ArrowRight className="size-4" /></a>
                    </aside>
                </section>
            </main>
        </>
    );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
    return <section className="mt-12"><h2 className="mb-4 text-xl font-bold">{title}</h2>{children}</section>;
}
