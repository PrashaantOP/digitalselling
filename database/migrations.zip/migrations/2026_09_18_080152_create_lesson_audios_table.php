<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lesson_audios', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lesson_id')->unique()->constrained('course_lessons')->cascadeOnDelete();
            $table->string('audio_url')->nullable();
            $table->string('audio_path')->nullable();
            $table->text('notes')->nullable();
            $table->integer('duration_seconds')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lesson_audios');
    }
};
